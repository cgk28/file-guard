// TrustMe wall v0.3 - tool.call interception.
// Layer A: protected core files (no write/edit/move/delete).
// Layer B: dangerous commands (exfil, remote-exec, secrets, persistence, destruction).
// Layer C: trust source - after reading untrusted content (web/peer) in the same run,
//          network/outbound/persistence actions are denied until the run ends.

const UNTRUSTED_TOOLS = ['web_fetch', 'web_search', 'browser', 'okdb_peer_read', 'okdb_peer_search', 'source_use'];

// strip quoting/concat tricks so 'AGE'+'NTS.md' and A`GENTS.md still match
function norm(v) {
  return String(v == null ? '' : v)
    .toLowerCase()
    .replace(/\\/g, '/')
    .replace(/[\x27\x22\x60^]/g, '')
    .replace(/\+/g, '')
    .replace(/\s+/g, ' ');
}

const WRITEY = /(>|\bout-file\b|\bset-content\b|\badd-content\b|\bclear-content\b|\bremove-item\b|\bmove-item\b|\brename-item\b|\bcopy-item\b|\bnew-item\b|\bsc\b|\bac\b|\bri\b|\bmi\b|\bcp\b|\brm\b|\bdel\b|\berase\b|\bmv\b|\bren\b|\bcopy\b|\bmove\b|\bsed\b|\btee\b|\bwritealltext\b|\bwriteallbytes\b|\bappendalltext\b|\bunlink\b|\bicacls\b|\battrib\b|\bopen\b.*\bw\b|\bpython\b|\bnode\b.*\bwrite|\bperl\b|\bruby\b)/;

const DANGEROUS = [
  [/(curl|wget|iwr|irm|invoke-webrequest|invoke-restmethod)[^|;]*\|\s*(sh|bash|zsh|iex|invoke-expression|powershell|pwsh)\b|\|\s*(python3?|node)\s*(-\s*$|$)/, 'remote code piped into an interpreter'],
  [/\b(iex|invoke-expression)\b.*\b(iwr|irm|downloadstring|invoke-webrequest|invoke-restmethod)\b/, 'download-and-execute'],
  [/\b(powershell|pwsh)\b.*\s-(e|enc|encodedcommand)\b/, 'encoded PowerShell command'],
  [/\bfromBase64String\b.*\b(iex|invoke-expression)\b|\bbase64\s+-d\b.*\|\s*(sh|bash)/i, 'decoded payload executed'],
  [/(curl|wget)\b.*\s(-d|--data\S*|--form|--upload-file|--post-(file|data))(\s|=|$)|\s-f\s+\S*=@|\b(invoke-restmethod|invoke-webrequest|irm|iwr)\b.*-(body|infile|method\s+(post|put))/, 'outbound upload / POST'],
  [/\bcertutil\b.*(urlcache|-f\b|-decode)|\bbitsadmin\b.*\/transfer|\bmshta\b|\bregsvr32\b.*\/i:http|\brundll32\b.*javascript/, 'living-off-the-land download / exec'],
  [/\b(scp|sftp|rsync|nc|ncat|netcat|ftp)\b/, 'raw data transfer tool'],
  [/(\.ssh\/|id_rsa|id_ed25519|(?<![\w])\.env(\.[\w-]+)?(\s|$|\/)|\.npmrc|\.pypirc|\/credentials(\.json|\.xml|\.db)?(\s|$)|credentials\.(json|xml|db)\b|\.aws\/|\.kube\/config|telegram\.sec|vault[^\s|;]*\.(json|db|key)\b|\.pem\b|\/cookies(\.sqlite)?(\s|$)|cookies\.sqlite|login data|wallet\.dat)/, 'reads a secret / credential store'],
  [/\b(schtasks\s+\/create|register-scheduledtask|new-scheduledtask|crontab\s+-)/, 'creates persistence (scheduled task)'],
  [/(currentversion\/run|\\run\\|\breg(\.exe)?\s+add\b|new-itemproperty.*\brun\b|start menu\/programs\/startup)/, 'creates persistence (autorun)'],
  [/\brm\s+-[a-z]*r[a-z]*f?\s+(\/|~|\$home|c:\/?)(\s|$|\*)|remove-item\b(?=.*-recurse)(?=.*-force)(?=.*\s(c:\/?(users\/?[^\/\s]*\/?)?|~\/?)(\s|$|\*))|\bformat\s+[a-z]:|\bmkfs\b|\bdd\s+if=.*of=\/dev/, 'destructive delete / format'],
  [/git\s+push\b.*(--force(?!-)|\s-f\b)|git\s+reset\s+--hard\s+origin/, 'force push / hard reset'],
  [/(set-mppreference|add-mppreference).*(exclusion|disable)|sc(\.exe)?\s+(stop|config)\s+windefend|netsh\s+advfirewall.*off/, 'weakens security tooling'],
];

// outbound / persistence actions that are denied after untrusted content was read
const TAINT_SENSITIVE = [
  [/\b(curl|wget|iwr|irm|invoke-webrequest|invoke-restmethod|scp|ssh|nc|ftp)\b/, 'network call from shell'],
  [/\b(npm|pip|pip3|npx|pnpm|yarn|winget|choco)\s+(i|install|add|-g)\b/, 'package install'],
  [/\b(schtasks|register-scheduledtask|reg\s+add|git\s+push|git\s+remote\s+add)\b/, 'persistence / publish'],
  [/(\b(start-process|invoke-item)|(^|[;&|]\s*)start)\s+.*\.(exe|msi|bat|cmd|ps1|vbs|js)\b/, 'runs a downloaded program'],
];
const TAINT_SENSITIVE_TOOLS = ['message', 'okdb_peer_propose', 'vault_fetch', 'vault_ssh', 'vault_use', 'source_use', 'gateway', 'cron'];

// ---- live terminal feed: which tools/skills are running, drawn in a Frame ----
function mask(s) { return String(s).replace(/[A-Za-z0-9_\-]{24,}/g, '***').replace(/\s+/g, ' ').slice(0, 90); }
function argOf(tool, p) {
  p = p || {};
  if (tool === 'skills_read') return p.name || '';
  return mask(p.command || p.cmd || p.file_path || p.path || p.url || p.query || p.name || p.action || '');
}
function hhmmss(ms) { return new Date(ms + 7 * 3600000).toISOString().slice(11, 19); }

exports.register = function (on, options) {
  async function feed($, patch, match) {
    const lines = ((await $.store.get('term')) || []).map((l) => ({ ...l }));
    if (match) {
      for (let i = lines.length - 1; i >= 0; i--) {
        if ((match.last || lines[i].id === match.id) && lines[i].st === 'run') {
          Object.assign(lines[i], patch);
          await $.store.set('term', lines);
          await $.ui.invalidate();
          return;
        }
      }
    }
    if (match) return;
    lines.push(patch);
    await $.store.set('term', lines.slice(-30));
    await $.ui.invalidate();
  }
  const key = (e) => e.sessionKey + ':' + e.tool;
  on('tool.call', async ($, e, next) => {
    const sk = e.tool === 'skills_read';
    await feed($, { id: key(e), at: hhmmss($.clock.now()), tool: sk ? 'skill ' + argOf(e.tool, e.params) : e.tool, skill: sk, arg: sk ? '' : argOf(e.tool, e.params), st: 'run' });
    return next(e);
  });
  on('tool.result', async ($, e, next) => {
    await feed($, { st: e.error ? 'err' : 'ok', ms: e.durationMs }, { id: key(e) });
    return next(e);
  });

  const names = String(options.protected || '').split('\n').map((s) => norm(s).trim()).filter(Boolean);
  const taintOn = options.taint !== false;
  const hit = (text) => names.find((n) => text.includes(n));

  async function deny($, layer, why, name) {
    await $.store.set('blocked', ((await $.store.get('blocked')) || 0) + 1);
    await feed($, { st: 'blk', why: why }, { last: true });
    await $.log.warn('[' + layer + '] blocked: ' + why + (name ? ' (' + name + ')' : ''));
    const last = [...((await $.store.get('last')) || [])];
    last.unshift(layer + ': ' + why);
    await $.store.set('last', last.slice(0, 5));
    return { deny: 'TrustMe [' + layer + ']: ' + why + '. Do not retry or work around it. Tell the owner what you wanted to do and wait for their explicit OK in chat.' };
  }

  // Layer A
  on('tool.call', { tool: ['write', 'edit', 'Write', 'Edit', 'apply_patch', 'notebook_edit'] }, async ($, e, next) => {
    const p = e.params || {};
    const n = hit(norm(p.file_path || p.path || p.filePath || p.target || JSON.stringify(p).slice(0, 2000)));
    return n ? deny($, 'files', 'protected core file "' + n + '"', n) : next(e);
  });

  // Layers A, B, C for shell
  on('tool.call', { tool: ['exec', 'bash', 'background_exec', 'process'] }, async ($, e, next) => {
    const p = e.params || {};
    const raw = String(p.command || p.cmd || p.data || p.text || '');
    const cmd = norm(raw);
    const n = hit(cmd);
    // 2>&1 and >nul / >$null are not file writes: drop them before the write test
    const cmdw = cmd.replace(/[=-]>/g, ' ').replace(/\d*>&\d+/g, ' ').replace(/\d*>\s*(\/dev\/null|\$null|nul)\b/g, ' ');
    if (n && WRITEY.test(cmdw)) return deny($, 'files', 'shell write on protected core file "' + n + '"', n);
    if (WRITEY.test(cmdw)) {
      for (const tok of cmd.split(/[\s|;,(){}]+/)) {
        if (!/[*?]/.test(tok)) continue;
        const base = tok.split('/').pop();
        const re = new RegExp('^' + base.replace(/[.+^$()|[\]\\{}]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$');
        const m = names.find((x) => re.test(x.split('/').pop()));
        if (m) return deny($, 'files', 'wildcard write may hit protected core file "' + m + '"', m);
      }
    }
    for (const [re, why] of DANGEROUS) if (re.test(cmd)) return deny($, 'danger', why);
    if (taintOn && (await $.store.get('taint:' + e.sessionKey))) {
      for (const [re, why] of TAINT_SENSITIVE) {
        if (re.test(cmd)) return deny($, 'trust', why + ' right after reading untrusted web/peer content (possible prompt injection)');
      }
    }
    return next(e);
  });

  // Layer C for non-shell tools
  on('tool.call', { tool: TAINT_SENSITIVE_TOOLS }, async ($, e, next) => {
    if (taintOn && (await $.store.get('taint:' + e.sessionKey))) {
      return deny($, 'trust', 'tool "' + e.tool + '" right after reading untrusted web/peer content (possible prompt injection)');
    }
    return next(e);
  });

  on('tool.result', { tool: UNTRUSTED_TOOLS }, async ($, e, next) => {
    await $.store.set('taint:' + e.sessionKey, Date.now());
    return next(e);
  });

  // a finished run clears the taint: the next user message is a fresh decision by the owner
  on('turn.end', async ($, e, next) => {
    await $.store.set('taint:' + e.sessionKey, null);
    return next(e);
  });

  on('ui.render', { slot: 'settings.section' }, async ($) => {
    const blocked = (await $.store.get('blocked')) || 0;
    const last = (await $.store.get('last')) || [];
    return h('Box', { direction: 'column', gap: 2 },
      h('Heading', { level: 3 }, 'TrustMe wall'),
      h('Text', { tone: 'muted' }, blocked + ' blocked. ' + names.length + ' protected path(s). Trust rule ' + (taintOn ? 'ON' : 'OFF') + '.'),
      ...last.map((l, i) => h('Text', { key: 'l' + i, tone: 'muted' }, l)));
  });
};
