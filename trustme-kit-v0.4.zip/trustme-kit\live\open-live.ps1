# Opens the TrustMe live window: a normal app window you can drag, resize, snap or put on another screen.
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
try { Invoke-WebRequest http://127.0.0.1:7077/feed -UseBasicParsing -TimeoutSec 1 | Out-Null }
catch { Start-Process node -ArgumentList "`"$dir\server.mjs`"" -WindowStyle Hidden; Start-Sleep 1 }
$edge = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
Start-Process $edge -ArgumentList '--app=http://127.0.0.1:7077', '--window-size=720,360', "--user-data-dir=$env:TEMP\trustme-live"
# pin on top (no extra software needed)
Add-Type 'using System;using System.Runtime.InteropServices;public class W{[DllImport("user32.dll")]public static extern bool SetWindowPos(IntPtr h,IntPtr a,int x,int y,int cx,int cy,uint f);}'
for ($i=0; $i -lt 15; $i++) {
  Start-Sleep -Milliseconds 400
  $p = Get-Process msedge -ErrorAction SilentlyContinue | Where-Object MainWindowTitle -like '*TrustMe*' | Select-Object -First 1
  if ($p) { [W]::SetWindowPos($p.MainWindowHandle, [IntPtr](-1), 0, 0, 0, 0, 0x13) | Out-Null; break }
}
