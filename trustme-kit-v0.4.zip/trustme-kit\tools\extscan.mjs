// extscan: secret + string scan with trufflehog and strings. usage: extscan.mjs <path> [--json]
import { spawnSync } from 'node:child_process';
import fs from 'node:fs'; import path from 'node:path'; import os from 'node:os';
const target = process.argv[2]; const json = process.argv.includes('--json');
const out = { target, at: new Date().toISOString(), trufflehog: null, strings: null, verdict: 'clean' };
if (!target || !fs.existsSync(target)) { console.error('usage: extscan.mjs <path> [--json]'); process.exit(3); }
const t = spawnSync('trufflehog', ['filesystem', target, '--no-update', '--json', '--results=verified,unverified,unknown'], { encoding: 'utf8', maxBuffer: 1 << 28 });
if (t.error) out.trufflehog = { available: false };
else {
  const hits = (t.stdout || '').split('\n').filter((l) => l.startsWith('{') && l.includes('DetectorName')).map((l) => { try { const j = JSON.parse(l); return { detector: j.DetectorName, verified: !!j.Verified, file: j.SourceMetadata?.Data?.Filesystem?.file }; } catch { return null; } }).filter(Boolean);
  out.trufflehog = { available: true, findings: hits.length, verified: hits.filter((h) => h.verified).length, hits: hits.slice(0, 20) };
  if (hits.length) out.verdict = hits.some((h) => h.verified) ? 'block' : 'review';
}
const bins = []; const walk = (p) => { for (const e of fs.readdirSync(p, { withFileTypes: true })) { const f = path.join(p, e.name); if (e.isDirectory()) { if (e.name !== 'node_modules' && e.name !== '.git') walk(f); } else if (/\.(exe|dll|so|bin|node|scr|com)$/i.test(e.name)) bins.push(f); } };
fs.statSync(target).isDirectory() ? walk(target) : bins.push(target);
const sus = new RegExp('(power'+'shell\\s+-e|From'+'Base64String|cmd\\.exe\\s*/c|discord(app)?\\.com/api/webhooks|api\\.telegram\\.org|pastebin\\.com|ngrok)','i');
const sres = []; let sOk = true;
for (const b of bins.slice(0, 50)) {
  const r = spawnSync('strings', ['-accepteula', '-nobanner', '-n', '8', b], { encoding: 'utf8', maxBuffer: 1 << 28 });
  if (r.error) { sOk = false; break; }
  const m = [...new Set((r.stdout || '').split('\n').filter((l) => sus.test(l)).map((l) => l.trim().slice(0, 160)))].slice(0, 10);
  if (m.length) sres.push({ file: b, matches: m });
}
out.strings = { available: sOk, binaries: bins.length, flagged: sres.length, hits: sres.slice(0, 10) };
if (sres.length && out.verdict === 'clean') out.verdict = 'review';
// stats for the TrustMe live window (counts only, no secrets)
try {
  const f = path.join(os.homedir(), 'aicoworker', 'aicwgw', 'plugins-data', 'file-guard-wall', 'extscan-stats.json');
  fs.mkdirSync(path.dirname(f), { recursive: true });
  let s = {}; try { s = JSON.parse(fs.readFileSync(f, 'utf8')); } catch {}
  s.scans = (s.scans || 0) + 1; s.findings = (s.findings || 0) + (out.trufflehog.findings || 0); s.flagged = (s.flagged || 0) + sres.length; s.last = { at: out.at, target: path.basename(target), verdict: out.verdict };
  fs.writeFileSync(f, JSON.stringify(s));
} catch {}
if (json) console.log(JSON.stringify(out, null, 1));
else { console.log(`extscan ${target}\n trufflehog: ${out.trufflehog.available ? out.trufflehog.findings + ' finding(s), ' + out.trufflehog.verified + ' verified' : 'NOT INSTALLED'}\n strings: ${out.strings.available ? out.strings.binaries + ' binaries, ' + out.strings.flagged + ' flagged' : 'NOT INSTALLED'}\n verdict: ${out.verdict}`); for (const h of out.trufflehog.hits || []) console.log('  [secret]', h.detector, h.verified ? '(VERIFIED)' : '', h.file || ''); for (const s of sres) console.log('  [strings]', s.file, '\n    ' + s.matches.join('\n    ')); }
process.exit(out.verdict === 'block' ? 2 : out.verdict === 'review' ? 1 : 0);
