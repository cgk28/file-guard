﻿// TrustMe live window: tiny local server (127.0.0.1 only) that serves the terminal page + the plugin feed.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
const dir = path.dirname(fileURLToPath(import.meta.url));
const store = path.join(os.homedir(), 'aicoworker', 'aicwgw', 'plugins-data', 'file-guard-wall', 'store.json');
const PORT = 7077;
http.createServer((req, res) => {
  if (req.url.startsWith('/feed')) {
    let out = { lines: [], blocked: 0 };
    try { const j = JSON.parse(fs.readFileSync(store, 'utf8')); out = { lines: (j.term || []).filter((x) => x.tool).slice(-40), blocked: j.blocked || 0 }; } catch {}
    res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    return res.end(JSON.stringify(out));
  }
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
  res.end(fs.readFileSync(path.join(dir, 'index.html')));
}).listen(PORT, '127.0.0.1', () => console.log('TrustMe live on http://127.0.0.1:' + PORT));

// Telegram alert when the wall blocks something new (message only, no secrets).
import { execFile } from 'node:child_process';
let seen = -1;
setInterval(() => {
  try {
    const j = JSON.parse(fs.readFileSync(store, 'utf8'));
    const n = j.blocked || 0;
    if (seen >= 0 && n > seen && fs.existsSync(path.join(dir, 'notify.ps1'))) {
      const msg = '⛔ TrustMe chặn ' + (n - seen) + ' hành động:\n' + (j.last || []).slice(-(n - seen)).join('\n');
      execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(dir, 'notify.ps1')], { env: { ...process.env, TM_MSG: msg }, windowsHide: true }, () => {});
    }
    seen = n;
  } catch {}
}, 5000);
