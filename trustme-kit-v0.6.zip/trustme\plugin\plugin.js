// TrustMe wall v0.3 - tool.call interception.
// Layer A: protected core files (no write/edit/move/delete).
// Layer B: dangerous commands (exfil, remote-exec, secrets, persistence, destruction).
// Layer C: trust source - after reading untrusted content (web/peer) in the same run,
//          network/outbound/persistence actions are denied until the run ends.

// <RULES> (generated from rules.json by build.js - do not edit by hand)
const RULES = {
 dangerous: [
  { re: new RegExp("(curl|wget|iwr|irm|invoke-webrequest|invoke-restmethod)[^|;]*\\|\\s*(sh|bash|zsh|iex|invoke-expression|powershell|pwsh)\\b|\\|\\s*(python3?|node)\\s*(-\\s*$|$)", ""), why: "remote code piped into an interpreter" },
  { re: new RegExp("\\b(iex|invoke-expression)\\b.*\\b(iwr|irm|downloadstring|invoke-webrequest|invoke-restmethod)\\b", ""), why: "download-and-execute" },
  { re: new RegExp("\\b(powershell|pwsh)\\b.*\\s-(e|enc|encodedcommand)\\b", ""), why: "encoded PowerShell command" },
  { re: new RegExp("\\bfromBase64String\\b.*\\b(iex|invoke-expression)\\b|\\bbase64\\s+-d\\b.*\\|\\s*(sh|bash)", "i"), why: "decoded payload executed" },
  { re: new RegExp("(curl|wget)\\b.*\\s(-d|--data\\S*|--form|--upload-file|--post-(file|data))(\\s|=|$)|\\s-f\\s+\\S*=@|\\b(invoke-restmethod|invoke-webrequest|irm|iwr)\\b.*-(body|infile|method\\s+(post|put))", ""), why: "outbound upload / POST" },
  { re: new RegExp("\\bcertutil\\b.*(urlcache|-f\\b|-decode)|\\bbitsadmin\\b.*\\/transfer|\\bmshta\\b|\\bregsvr32\\b.*\\/i:http|\\brundll32\\b.*javascript", ""), why: "living-off-the-land download / exec" },
  { re: new RegExp("\\b(scp|sftp|rsync|nc|ncat|netcat|ftp)\\b", ""), why: "raw data transfer tool" },
  { re: new RegExp("(\\.ssh\\/|id_rsa|id_ed25519|(?<![\\w])\\.env(\\.[\\w-]+)?(\\s|$|\\/)|\\.npmrc|\\.pypirc|\\/credentials(\\.json|\\.xml|\\.db)?(\\s|$)|credentials\\.(json|xml|db)\\b|\\.aws\\/|\\.kube\\/config|telegram\\.sec|vault[^\\s|;]*\\.(json|db|key)\\b|\\.pem\\b|\\/cookies(\\.sqlite)?(\\s|$)|cookies\\.sqlite|login data|wallet\\.dat)", ""), why: "reads a secret / credential store" },
  { re: new RegExp("\\b(schtasks\\s+\\/create|register-scheduledtask|new-scheduledtask|crontab\\s+-)", ""), why: "creates persistence (scheduled task)" },
  { re: new RegExp("(?:(?=.*(?:\\b(?:copy|copy-item|move|move-item|cp|mv|xcopy|robocopy|set-content|add-content|out-file|new-item|ni|mklink|tee|echo|set-itemproperty|sp|reg\\s+import|expand-archive)\\b|>)).*(?:currentversion\\/run|start menu\\/programs\\/startup)|\\breg(\\.exe)?\\s+add\\b|new-itemproperty.*\\brun\\b)", ""), why: "creates persistence (autorun)" },
  { re: new RegExp("\\brm\\s+-[a-z]*r[a-z]*f?\\s+(\\/|~|\\$home|c:\\/?)(\\s|$|\\*)|remove-item\\b(?=.*-recurse)(?=.*-force)(?=.*\\s(c:\\/?(users\\/?[^\\/\\s]*\\/?)?|~\\/?)(\\s|$|\\*))|\\bformat\\s+[a-z]:|\\bmkfs\\b|\\bdd\\s+if=.*of=\\/dev", ""), why: "destructive delete / format" },
  { re: new RegExp("git\\s+push\\b.*(--force(?!-)|\\s-f\\b)|git\\s+reset\\s+--hard\\s+origin", ""), why: "force push / hard reset" },
  { re: new RegExp("(set-mppreference|add-mppreference).*(exclusion|disable)|sc(\\.exe)?\\s+(stop|config)\\s+windefend|netsh\\s+advfirewall.*off", ""), why: "weakens security tooling" }
],
 taintSensitive: [
  { re: new RegExp("\\b(curl|wget|iwr|irm|invoke-webrequest|invoke-restmethod|scp|ssh|nc|ftp)\\b", ""), why: "network call from shell" },
  { re: new RegExp("\\b(npm|pip|pip3|npx|pnpm|yarn|winget|choco)\\s+(i|install|add|-g)\\b", ""), why: "package install" },
  { re: new RegExp("\\b(schtasks|register-scheduledtask|reg\\s+add|git\\s+push|git\\s+remote\\s+add)\\b", ""), why: "persistence / publish" },
  { re: new RegExp("(\\b(start-process|invoke-item)|(^|[;&|]\\s*)start)\\s+.*\\.(exe|msi|bat|cmd|ps1|vbs|js)\\b", ""), why: "runs a downloaded program" }
],
 contentExtra: [
  { re: new RegExp("\\b(eval|new function)\\s*\\(", "i"), why: "dynamic code execution in file" },
  { re: new RegExp("\\bchild_process\\b|\\bsubprocess\\b|\\bos\\.system\\b|\\bstart-process\\b", "i"), why: "spawns processes" },
  { re: new RegExp("\\bfetch\\s*\\(|\\bxmlhttprequest\\b|https?\\.request|require\\(['\"]https?['\"]\\)|net\\.webclient|system\\.net\\.sockets|\\bsocket\\b|urllib|\\brequests\\.(get|post)", "i"), why: "network access in file" },
  { re: new RegExp("fromBase64String|atob\\s*\\(|buffer\\.from\\([^)]*base64", "i"), why: "decodes hidden payload" }
],
 untrustedTools: ["web_fetch","web_search","browser","okdb_peer_read","okdb_peer_search","source_use"],
 taintSensitiveTools: ["message","okdb_peer_propose","vault_fetch","vault_ssh","vault_use","source_use","gateway","cron"],
 executableExt: ["js","mjs","cjs","ps1","bat","cmd","sh","py","vbs","exe","msi","jar","rb","pl","php"],
};
// </RULES>
const UNTRUSTED_TOOLS = RULES.untrustedTools;

// strip quoting/concat tricks so 'AGE'+'NTS.md' and A`GENTS.md still match
function norm(v) {
  return String(v == null ? '' : v)
    .toLowerCase()
    .replace(/\\/g, '/')
    .replace(/[\x27\x22\x60^]/g, '')
    .replace(/\+/g, '')
    .replace(/\s+/g, ' ');
}

const WRITEY = /(>|\bout-file\b|\bset-content\b|\badd-content\b|\bclear-content\b|\bremove-item\b|\bmove-item\b|\brename-item\b|\bcopy-item\b|\bnew-item\b|\bsc\b|\bac\b|\bri\b|\bmi\b|\bcp\b|\brm\b|\bdel\b|\berase\b|\bmv\b|\bren\b|\bcopy\b|\bmove\b|\bsed\b|\btee\b|\bwritealltext\b|\bwriteallbytes\b|\bappendalltext\b|\bunlink\b|\bicacls\b|\battrib\b|\bopen\b.*\bw\b|\bpython\b|\bnode\b.*\bwrite|\bperl\b|\bruby\b)/;

const DANGEROUS = RULES.dangerous;;

// outbound / persistence actions that are denied after untrusted content was read
const TAINT_SENSITIVE = RULES.taintSensitive;;
const TAINT_SENSITIVE_TOOLS = RULES.taintSensitiveTools;

// ---- live terminal feed: which tools/skills are running, drawn in a Frame ----
function mask(s) { return String(s).replace(/[A-Za-z0-9_\-]{24,}/g, '***').replace(/\s+/g, ' ').slice(0, 90); }
function argOf(tool, p) {
  p = p || {};
  if (tool === 'skills_read') return p.name || '';
  return mask(p.command || p.cmd || p.file_path || p.path || p.url || p.query || p.name || p.action || '');
}
function hhmmss(ms) { return new Date(ms + 7 * 3600000).toISOString().slice(11, 19); }

exports.register = function (on, options) {
  async function feed($, patch, match) {
    const lines = ((await $.store.get('term')) || []).map((l) => ({ ...l }));
    if (match) {
      for (let i = lines.length - 1; i >= 0; i--) {
        if ((match.last || lines[i].id === match.id) && lines[i].st === 'run') {
          Object.assign(lines[i], patch);
          await $.store.set('term', lines);
          await $.ui.invalidate();
          return;
        }
      }
    }
    if (match) return;
    lines.push(patch);
    await $.store.set('term', lines.slice(-30));
    await $.ui.invalidate();
  }
  const key = (e) => e.sessionKey + ':' + e.tool;

  // ---- v0.5: mode, audit log, content scan (fs is optional: without it we degrade to name-based blocking) ----
  let fs = null, osm = null, pathm = null;
  try { fs = require('fs'); osm = require('os'); pathm = require('path'); } catch (_) {}
  const envv = (typeof process !== 'undefined' && process.env) || {};
  const MODE = ['strict', 'normal', 'lenient'].includes(options.mode || envv.TRUSTME_MODE) ? (options.mode || envv.TRUSTME_MODE) : 'normal';
  const AUDIT = options.auditPath || envv.TRUSTME_AUDIT || (osm ? pathm.join(osm.homedir(), '.trustme', 'audit.jsonl') : null);
  let CUR = null;
  // hole 1 (sensitive call before a sibling web call in the same step): wait a moment, then re-check the mark
  const SETTLE = Number(options.settleMs != null ? options.settleMs : (envv.TRUSTME_SETTLE_MS != null ? envv.TRUSTME_SETTLE_MS : 0));
  const sleep = (ms) => new Promise((r) => { try { setTimeout(r, ms); } catch (_) { r(); } });
  const isSensitiveCmd = (c) => RULES.taintSensitive.some((r) => r.re.test(c));
  async function lateCheck($, e) {
    const sk = 'sens:' + e.sessionKey;
    const s0 = await $.store.get(sk);
    if (!s0) return;
    await $.store.set(sk, null);
    if ($.clock.now() - s0.at > 8000) return;
    const text = 'late taint: "' + s0.why + '" ran just before untrusted content was read in the same step';
    audit({ verdict: 'late-taint', layer: 'trust', why: text });
    const al = ((await $.store.get('alerts')) || []).concat([{ t: new Date().toISOString(), text }]).slice(-50);
    await $.store.set('alerts', al);
  }
  const auditQ = [];
  async function auditFlush($) {
    if (!auditQ.length) return;
    const cur = ((await $.store.get('audit')) || []).concat(auditQ.splice(0)).slice(-300);
    await $.store.set('audit', cur);
  }
  function audit(rec) {
    if (!fs || !AUDIT) { auditQ.push({ t: new Date().toISOString(), mode: MODE, tool: (CUR || {}).tool, ...rec }); return; }
    try {
      fs.mkdirSync(pathm.dirname(AUDIT), { recursive: true });
      try { if (fs.statSync(AUDIT).size > 2000000) fs.renameSync(AUDIT, AUDIT + '.1'); } catch (_) {}
      const e = CUR || {};
      fs.appendFileSync(AUDIT, JSON.stringify({ t: new Date().toISOString(), mode: MODE, tool: e.tool, session: e.sessionKey, arg: argOf(e.tool, e.params), ...rec }) + '\n');
    } catch (_) {}
  }
  // only real file names: known extensions, no code fragments like p.text
  const FILE_TOK = new RegExp('^[\\w\\-./\\\\:~%]+\\.(' + RULES.executableExt.concat(['md', 'txt', 'json', 'html', 'css', 'yml', 'yaml', 'ini', 'cfg', 'conf', 'log', 'csv', 'xml', 'dll', 'lnk', 'toml']).join('|') + ')' + String.fromCharCode(36), 'i');
  const EXEC_EXT = new RegExp('\\.(' + RULES.executableExt.join('|') + ')$', 'i');
  // returns a reason when the text looks like an attack payload, else null
  function scanText(text) {
    const t = String(text || '').slice(0, 1000000).toLowerCase().replace(/\s+/g, ' ');
    for (const r of RULES.dangerous) if (r.re.test(t)) return r.why;
    for (const r of RULES.taintSensitive) if (r.re.test(t)) return r.why;
    for (const r of RULES.contentExtra) if (r.re.test(t)) return r.why;
    return null;
  }
  // find the flagged file on disk from the raw command; null = could not read it
  function readFlagged(raw, name, cwd) {
    if (!fs) return null;
    const toks = String(raw).replace(/["'`]/g, ' ').split(/[\s|;,(){}<>=]+/).filter((x) => x.toLowerCase().replace(/\\/g, '/').split('/').pop() === name);
    for (const tk of toks) {
      const cands = [tk];
      if (cwd) cands.push(pathm.resolve(cwd, tk));
      cands.push(pathm.resolve(process.cwd(), tk));
      for (const c of cands) { try { if (fs.statSync(c).isFile()) return fs.readFileSync(c, 'utf8'); } catch (_) {} }
    }
    return null;
  }
  on('tool.call', async ($, e, next) => {
    CUR = e;
    const sk = e.tool === 'skills_read';
    await feed($, { id: key(e), at: hhmmss($.clock.now()), tool: sk ? 'skill ' + argOf(e.tool, e.params) : e.tool, skill: sk, arg: sk ? '' : argOf(e.tool, e.params), st: 'run' });
    return next(e);
  });
  on('tool.result', async ($, e, next) => {
    await feed($, { st: e.error ? 'err' : 'ok', ms: e.durationMs }, { id: key(e) });
    return next(e);
  });

  // Layer D: files written while untrusted content was in play may not be executed later
  const TF_TTL = (options.tfilesTtlHours || 6) * 3600000;
  // does the command RUN this file? Only when the name is an argument right after an interpreter (and its flags),
  // or the command itself. Mentioning the name inside code (writeFileSync('x.js',...)) or reading it does not count.
  const RUNWORDS = 'node|python3?|py|powershell|pwsh|bash|sh|zsh|cmd|call|source|iex|invoke-expression|invoke-item|start-process|start|wscript|cscript|java|ruby|perl|php|deno|bun|npx|tsx|dotnet|ts-node';
  const escRe = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  function runsFlagged(cmd, name) {
    const n = escRe(name), end = '(?=$|[\\s;|&])';
    const viaInterp = new RegExp('(?:^|[\\s;&|(])(?:' + RUNWORDS + ')(?:\\s+(?:-\\S+|/\\S+))*\\s+[^\\s;|&]*' + n + end);
    const direct = new RegExp('(?:^|[;&|(]\\s*)&?\\s*[^\\s;|&]*' + n + end);
    return viaInterp.test(cmd) || direct.test(cmd);
  }
  async function tfList($) {
    const now = $.clock.now();
    return ((await $.store.get('tfiles')) || []).filter((x) => now - x.at < TF_TTL);
  }
  async function tfAdd($, items, clean) {
    const cur = await tfList($);
    for (const f of items) {
      if (!f || f.length < 3) continue;
      const ex = cur.find((x) => x.f === f);
      if (ex) { ex.at = $.clock.now(); ex.clean = !!clean; } else cur.push({ f, at: $.clock.now(), clean: !!clean });
    }
    await $.store.set('tfiles', cur.slice(-200));
  }
  const names = String(options.protected || '').split('\n').map((s) => norm(s).trim()).filter(Boolean);
  const taintOn = options.taint !== false;
  const hit = (text) => names.find((n) => text.includes(n));

  async function deny($, layer, why, name) {
    await $.store.set('blocked', ((await $.store.get('blocked')) || 0) + 1);
    await feed($, { st: 'blk', why: why }, { last: true });
    audit({ verdict: 'deny', layer, why });
    await auditFlush($);
    await $.log.warn('[' + layer + '] blocked: ' + why + (name ? ' (' + name + ')' : ''));
    const last = [...((await $.store.get('last')) || [])];
    last.unshift(layer + ': ' + why);
    await $.store.set('last', last.slice(0, 5));
    return { deny: 'TrustMe [' + layer + ']: ' + why + '. Do not retry or work around it. Tell anh Khang what you wanted to do and wait for his explicit OK in chat.' };
  }

  // Layer A
  on('tool.call', { tool: ['write', 'edit', 'Write', 'Edit', 'apply_patch', 'notebook_edit'] }, async ($, e, next) => {
    const p = e.params || {};
    const n = hit(norm(p.file_path || p.path || p.filePath || p.target || JSON.stringify(p).slice(0, 2000)));
    if (n) return deny($, 'files', 'protected core file "' + n + '"', n);
    if (taintOn && (await $.store.get('taint:' + e.sessionKey))) {
      const t = norm(p.file_path || p.path || p.filePath || p.target || '').split('/').pop();
      if (t && EXEC_EXT.test(t)) {
        if (MODE === 'strict') return deny($, 'trust', 'writes executable "' + t + '" right after reading untrusted web/peer content (strict mode)');
        const bad = scanText(p.content || p.new_string || p.new_str || p.text || p.file_text || '');
        if (bad) return deny($, 'trust', 'writes code that does "' + bad + '" right after reading untrusted web/peer content');
      }
      if (t && MODE !== 'lenient') await tfAdd($, [t], EXEC_EXT.test(t) && String(p.content || p.new_string || p.new_str || p.text || p.file_text || '').length > 0);
    }
    return next(e);
  });

  // Layers A, B, C for shell
  on('tool.call', { tool: ['exec', 'bash', 'background_exec', 'process'] }, async ($, e, next) => {
    const p = e.params || {};
    const raw = String(p.command || p.cmd || p.data || p.text || '');
    const cmd = norm(raw);
    const n = hit(cmd);
    // 2>&1 and >nul / >$null are not file writes: drop them before the write test
    const cmdw = cmd.replace(/[=-]>/g, ' ').replace(/\d*>&\d+/g, ' ').replace(/\d*>\s*(\/dev\/null|\$null|nul)\b/g, ' ');
    if (n && WRITEY.test(cmdw)) return deny($, 'files', 'shell write on protected core file "' + n + '"', n);
    if (WRITEY.test(cmdw)) {
      // variable in a path: judge by the literal tail, e.g. "${f}ts.md"
      for (const vm of cmd.matchAll(/\$(?:\{[^}]*\}|\([^)]*\)|\w+)([\w.\-]{3,})/g)) {
        const mv = names.find((x) => x.split('/').pop().endsWith(vm[1]));
        if (mv) return deny($, 'files', 'variable path may hit protected core file "' + mv + '"', mv);
      }
      for (const tok of cmd.split(/[\s|;,(){}]+/)) {
        const base = tok.split('/').pop();
        if (!/[*?\[]/.test(tok)) continue;
        let src = '';
        for (let i = 0; i < base.length; i++) {
          const ch = base[i];
          if (ch === '*') src += '.*';
          else if (ch === '?') src += '.';
          else if (ch === '[' && base.indexOf(']', i) > i) { const j = base.indexOf(']', i); src += '[' + base.slice(i + 1, j).replace(/[\\\]^]/g, '\\$&') + ']'; i = j; }
          else src += ch.replace(/[.+^$()|[\]\\{}]/g, '\\$&');
        }
        let re; try { re = new RegExp('^' + src + '$'); } catch { continue; }
        const m = names.find((x) => re.test(x.split('/').pop()));
        if (m) return deny($, 'files', 'wildcard write may hit protected core file "' + m + '"', m);
      }
    }
    for (const r of RULES.dangerous) if (r.re.test(cmd)) return deny($, 'danger', r.why);
    let tainted = taintOn && (await $.store.get('taint:' + e.sessionKey));
    if (taintOn && !tainted && SETTLE > 0 && isSensitiveCmd(cmd)) { await sleep(SETTLE); tainted = await $.store.get('taint:' + e.sessionKey); }
    if (taintOn && !tainted && isSensitiveCmd(cmd)) await $.store.set('sens:' + e.sessionKey, { at: $.clock.now(), why: 'shell ' + mask(raw) });
    if (tainted) {
      for (const r of RULES.taintSensitive) {
        const why = r.why;
        if (MODE === 'lenient' && why === 'package install') continue;
        if (r.re.test(cmd)) return deny($, 'trust', why + ' right after reading untrusted web/peer content (possible prompt injection)');
      }
      // remember what gets written now: it must not be run later
      if (WRITEY.test(cmdw) && MODE !== 'lenient') await tfAdd($, cmd.split(/[\s|;,(){}<>=]+/).filter((t) => FILE_TOK.test(t)).map((t) => t.split('/').pop()));
    }
    // propagation: rename/copy/write that mentions a flagged file flags every file in that command
    if (taintOn && !tainted && WRITEY.test(cmdw) && (await tfList($)).some((x) => cmd.includes(x.f))) {
      await tfAdd($, cmd.split(/[\s|;,(){}<>=]+/).filter((t) => FILE_TOK.test(t)).map((t) => t.split('/').pop()));
    }
    if (taintOn && MODE !== 'lenient') {
      const hitf = (await tfList($)).find((x) => EXEC_EXT.test(x.f) && cmd.includes(x.f) && runsFlagged(cmd, x.f));
      if (hitf) {
        if (MODE === 'strict') return deny($, 'trust', 'runs "' + hitf.f + '", a file written while untrusted web/peer content was in play (strict mode)');
        if (hitf.clean) {
          audit({ verdict: 'allow', layer: 'trust', why: 'flagged file was scanned clean when written: ' + hitf.f });
          await auditFlush($);
          return next(e);
        }
        const body = readFlagged(raw, hitf.f, e.cwd);
        if (body == null) return deny($, 'trust', 'runs "' + hitf.f + '", written while untrusted content was in play, and its content cannot be read to verify');
        const bad = scanText(body);
        if (bad) return deny($, 'trust', 'runs "' + hitf.f + '" which contains: ' + bad);
        audit({ verdict: 'allow', layer: 'trust', why: 'flagged file scanned clean: ' + hitf.f });
      }
    }
    return next(e);
  });

  // Layer C for non-shell tools
  on('tool.call', { tool: TAINT_SENSITIVE_TOOLS }, async ($, e, next) => {
    let t = taintOn && (await $.store.get('taint:' + e.sessionKey));
    if (taintOn && !t && SETTLE > 0) { await sleep(SETTLE); t = await $.store.get('taint:' + e.sessionKey); }
    if (t) return deny($, 'trust', 'tool "' + e.tool + '" right after reading untrusted web/peer content (possible prompt injection)');
    if (taintOn) await $.store.set('sens:' + e.sessionKey, { at: $.clock.now(), why: 'tool ' + e.tool });
    return next(e);
  });

  // mark at CALL time too: parallel calls in the same step must not slip through before the result arrives
  on('tool.call', { tool: UNTRUSTED_TOOLS }, async ($, e, next) => {
    if (taintOn) { await lateCheck($, e); await $.store.set('taint:' + e.sessionKey, Date.now()); }
    return next(e);
  });

  on('tool.result', { tool: UNTRUSTED_TOOLS }, async ($, e, next) => {
    CUR = e;
    await lateCheck($, e);
    audit({ verdict: 'mark', layer: 'trust', why: 'untrusted content read' });
    await auditFlush($);
    await $.store.set('taint:' + e.sessionKey, Date.now());
    return next(e);
  });

  // a finished run clears the taint: the next user message is a fresh decision by the owner
  on('turn.end', async ($, e, next) => {
    await $.store.set('taint:' + e.sessionKey, null);
    return next(e);
  });

  on('ui.render', { slot: 'settings.section' }, async ($) => {
    const blocked = (await $.store.get('blocked')) || 0;
    const last = (await $.store.get('last')) || [];
    return h('Box', { direction: 'column', gap: 2 },
      h('Heading', { level: 3 }, 'TrustMe wall'),
      h('Text', { tone: 'muted' }, blocked + ' blocked. ' + names.length + ' protected path(s). Mode ' + MODE + '. Trust rule ' + (taintOn ? 'ON' : 'OFF') + '.'),
      ...last.map((l, i) => h('Text', { key: 'l' + i, tone: 'muted' }, l)));
  });
};
