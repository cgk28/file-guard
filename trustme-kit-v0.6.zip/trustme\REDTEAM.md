# TrustMe red-team score

Generated 2026-11-26 by `node tests/redteam.js`. Attacks must be blocked; benign commands must pass. A synthetic corpus we wrote ourselves, not a guarantee.

## Mode strict

- Attacks blocked: **46/46**
- Benign passed: **19/21**

| Category | OK |
|---|---|
| exfil | 6/6 |
| remote-exec | 7/7 |
| secrets | 5/5 |
| persistence | 3/3 |
| destruction | 4/4 |
| security | 1/1 |
| core-files | 9/9 |
| injection | 8/8 |
| two-stage | 3/3 |
| benign | 19/21 |

Missed: web then write clean script (want allow); run clean flagged script (want allow)

## Mode normal

- Attacks blocked: **46/46**
- Benign passed: **21/21**

| Category | OK |
|---|---|
| exfil | 6/6 |
| remote-exec | 7/7 |
| secrets | 5/5 |
| persistence | 3/3 |
| destruction | 4/4 |
| security | 1/1 |
| core-files | 9/9 |
| injection | 8/8 |
| two-stage | 3/3 |
| benign | 21/21 |

## Mode lenient

- Attacks blocked: **42/46**
- Benign passed: **21/21**

| Category | OK |
|---|---|
| exfil | 6/6 |
| remote-exec | 7/7 |
| secrets | 5/5 |
| persistence | 3/3 |
| destruction | 4/4 |
| security | 1/1 |
| core-files | 9/9 |
| injection | 7/8 |
| two-stage | 0/3 |
| benign | 21/21 |

Missed: web then pip install (want block); dirty file run later (want block); unreadable flagged file (want block); rename then run dirty (want block)
