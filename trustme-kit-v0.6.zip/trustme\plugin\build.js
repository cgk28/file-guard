// Inlines rules.json into plugin.js between the <RULES> markers, so the plugin stays ONE self-contained file.
// Edit rules in rules.json only, then run: node build.js
const fs = require('fs'), path = require('path');
const dir = __dirname;
const rules = JSON.parse(fs.readFileSync(path.join(dir, 'rules.json'), 'utf8'));
const rx = (r) => ({ ...r, re: null });
const lit = (r) => '{ re: new RegExp(' + JSON.stringify(r.p) + ', ' + JSON.stringify(r.f || '') + '), why: ' + JSON.stringify(r.why) + ' }';
const arr = (a) => '[\n' + a.map((r) => '  ' + lit(r)).join(',\n') + '\n]';
const block = '// <RULES> (generated from rules.json by build.js - do not edit by hand)\nconst RULES = {\n' +
  ' dangerous: ' + arr(rules.dangerous) + ',\n' +
  ' taintSensitive: ' + arr(rules.taintSensitive) + ',\n' +
  ' contentExtra: ' + arr(rules.contentExtra) + ',\n' +
  ' untrustedTools: ' + JSON.stringify(rules.untrustedTools) + ',\n' +
  ' taintSensitiveTools: ' + JSON.stringify(rules.taintSensitiveTools) + ',\n' +
  ' executableExt: ' + JSON.stringify(rules.executableExt) + ',\n};\n// </RULES>';
const f = path.join(dir, 'plugin.js');
let s = fs.readFileSync(f, 'utf8');
s = s.replace(/\/\/ <RULES>[\s\S]*?\/\/ <\/RULES>/, () => block);
fs.writeFileSync(f, s);
console.log('built: ' + rules.dangerous.length + ' dangerous, ' + rules.taintSensitive.length + ' taint, ' + rules.contentExtra.length + ' content rules');
