// Finds the external scanners: on PATH first, then in the WinGet packages folder (winget does not always add them to PATH).
import { spawnSync } from 'node:child_process';
import fs from 'node:fs'; import path from 'node:path';
const WG = path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Packages');
export function find(names) {
  for (const n of names) { const r = spawnSync(process.platform === 'win32' ? 'where' : 'which', [n], { encoding: 'utf8' }); if (r.status === 0) return n; }
  try {
    const want = names.map((n) => n.toLowerCase() + '.exe');
    for (const d of fs.readdirSync(WG)) { const dir = path.join(WG, d); let files = []; try { files = fs.readdirSync(dir); } catch { continue; }
      for (const w of want) { const hit = files.find((f) => f.toLowerCase() === w); if (hit) return path.join(dir, hit); } }
  } catch {}
  return null;
}
export const secretsTool = () => { const t = find(['trufflehog']); if (t) return { name: 'trufflehog', bin: t }; const g = find(['gitleaks']); return g ? { name: 'gitleaks', bin: g } : null; };
export const stringsBin = () => find(['strings64', 'strings']);
