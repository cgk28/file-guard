@echo off
rem TrustMe owner-only. Run with AICoworker CLOSED.
rem 1) clears the "flagged files" list  2) runs the tests  3) only if they pass, installs the fixed plugin.
set P=%USERPROFILE%\aicoworker\aicwgw\plugins\file-guard-wall
set S=%USERPROFILE%\aicoworker\aicwgw\plugins-data\file-guard-wall\store.json
set W=%USERPROFILE%\aicoworker\aicwgw\workspace-main\projects\trustme
node -e "const f=process.argv[1];const j=require(f);console.log('Flagged before:',(j.tfiles||[]).map(x=>x.f).join(', ')||'(none)');delete j.tfiles;require('fs').writeFileSync(f,JSON.stringify(j));console.log('Flags cleared.')" "%S%"
echo.
echo Running tests...
node "%W%\adapters\claude-code\test.js" | findstr /C:"ALL PASS" /C:"FAIL"
node "%W%\tests\redteam.js" normal
if errorlevel 1 (echo TESTS FAILED - plugin NOT updated. & pause & exit /b 1)
copy /Y "%W%\plugin\plugin.js" "%P%\plugin.js" >nul
copy /Y "%W%\plugin\rules.json" "%P%\rules.json" >nul
echo.
echo Plugin updated. Now open AICoworker again and tell Chu "xong".
pause
