# TrustMe for Claude Code

Same rules as the AICoworker plugin, no copy of the rules: this hook loads `../../plugin/plugin.js`.

Add to `~/.claude/settings.json` (replace the path):

```json
{
  "hooks": {
    "PreToolUse":  [{ "matcher": "*", "hooks": [{ "type": "command", "command": "node /path/to/trustme/adapters/claude-code/trustme-hook.js" }] }],
    "PostToolUse": [{ "matcher": "WebFetch|WebSearch", "hooks": [{ "type": "command", "command": "node /path/to/trustme/adapters/claude-code/trustme-hook.js" }] }],
    "Stop":        [{ "hooks": [{ "type": "command", "command": "node /path/to/trustme/adapters/claude-code/trustme-hook.js" }] }]
  }
}
```

- Blocked call: exit code 2, the reason goes to the model.
- State (untrusted-content mark) lives in `~/.trustme/state.json`. Override with `TRUSTME_STATE`.
- Protected paths: env `TRUSTME_PROTECTED` (one per line). Default covers CLAUDE.md, AGENTS.md, SOUL.md, settings.json, `.claude/`.
- Limits: same as the plugin (regex rules can be evaded; only sees tool names and params).
