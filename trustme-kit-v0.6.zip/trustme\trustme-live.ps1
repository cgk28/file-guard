# TrustMe live terminal: colored feed of running tools/skills, in its own window.
# Run:  powershell -ExecutionPolicy Bypass -File trustme-live.ps1   (Ctrl+C to quit)
param([string]$Store = "$env:USERPROFILE\aicoworker\aicwgw\plugins-data\file-guard-wall\store.json")
$e = [char]27
function C($n, $t) { "$e[${n}m$t$e[0m" }
$last = ''
[Console]::OutputEncoding = [Text.Encoding]::UTF8
try { $Host.UI.RawUI.WindowTitle = 'TrustMe live' } catch {}
while ($true) {
  try {
    $raw = Get-Content $Store -Raw -ErrorAction Stop
    if ($raw -ne $last) {
      $last = $raw
      $lines = @(($raw | ConvertFrom-Json).term | Where-Object { $_.tool }) | Select-Object -Last 25
      Clear-Host
      Write-Host (C '1;32' 'TrustMe') (C '90' '- live tools & skills') (C '90' (Get-Date -Format 'HH:mm:ss'))
      Write-Host (C '90' ('-' * 60))
      foreach ($x in $lines) {
        $name = if ($x.skill) { C '1;35' ([string][char]0x25C6 + ' ' + $x.tool) } else { C '1;36' ('$ ' + $x.tool) }
        $st = switch ($x.st) {
          'run' { C '33' 'running...' }
          'ok'  { (C '32' 'ok') + ' ' + (C '35' ("$($x.ms)ms")) }
          'err' { C '31' 'ERROR' }
          'blk' { (C '97;41' ' BLOCKED ') + ' ' + (C '31' $x.why) }
          default { '' }
        }
        Write-Host ((C '90' $x.at) + ' ' + $name + ' ' + (C '90' $x.arg) + ' ' + $st)
      }
    }
  } catch {}
  Start-Sleep -Milliseconds 700
}
