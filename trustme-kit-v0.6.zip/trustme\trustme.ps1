# TrustMe - one command for the 3 layers.   usage: trustme.ps1 status | install | live
param([string]$Cmd = "status")
$ws    = if ($env:TRUSTME_WORKSPACE) { $env:TRUSTME_WORKSPACE } else { (Get-Location).Path }   # agent workspace
$node  = if (Get-Command node -ErrorAction SilentlyContinue) { (Get-Command node).Source } else { "node" }
$fg    = "$ws\skills\file-guard\scripts\file-guard.mjs"
$plug  = if ($env:TRUSTME_PLUGIN_DIR) { $env:TRUSTME_PLUGIN_DIR } else { "$env:USERPROFILE\aicoworker\aicwgw\plugins\file-guard-wall" }
$watch = "$ws\tools\file-guard-watch\watch.ps1"
$task  = "Chu-FileGuardWatch"

if ($Cmd -eq "live") { & "$PSScriptRoot\live\open-live.ps1"; exit }

function Show($n, $ok, $detail) { "{0,-22} {1,-5} {2}" -f $n, $(if ($ok) { "OK" } else { "FAIL" }), $detail }

if ($Cmd -eq "install") {
  schtasks /create /tn $task /sc hourly /tr "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File $watch" /f | Out-Null
  "Task installed. The plugin must be turned on by the owner: AI Coworker > Plugins > TrustMe wall."
  "Baseline is signed by the owner with a one-time Telegram code: file-guard.mjs rebaseline --dir $ws"
}

# Layer 1: detect (signed baseline)
$out = (& $node $fg check --dir $ws 2>&1 | Out-String)
Show "1 detect (baseline)" ($LASTEXITCODE -eq 0) ($out.Trim() -split "`n" | Select-Object -First 1)

# Layer 2: block (plugin present; enabled state is owner-only, see its log)
$ok = (Test-Path "$plug\plugin.js") -and (Test-Path "$plug\plugin.json")
$ver = if ($ok) { (Get-Content "$plug\plugin.json" -Raw | ConvertFrom-Json).version } else { "-" }
Show "2 block (plugin)" $ok "files present, v$ver. Turned on? check AI Coworker > Plugins"

# Layer 3: alarm (scheduled task)
$q = schtasks /query /tn $task /v /fo list 2>$null | Out-String
$res = if ($q -match "Last Result:\s+(\S+)") { $Matches[1] } else { "none" }
Show "3 alarm (task)" ($q -ne "" -and $res -eq "0") "last result $res"
