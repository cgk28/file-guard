﻿# Anh Khang chạy 1 lần: thêm báo Telegram vào server TrustMe rồi khởi động lại nó.
$d = Split-Path -Parent $MyInvocation.MyCommand.Path
$f = Join-Path $d 'server.mjs'
$js = Get-Content $f -Raw
if ($js -notmatch 'TM_MSG') {
$add = @'

// Telegram alert when the wall blocks something new (message only, no secrets).
import { execFile } from 'node:child_process';
let seen = -1;
setInterval(() => {
  try {
    const j = JSON.parse(fs.readFileSync(store, 'utf8'));
    const n = j.blocked || 0;
    if (seen >= 0 && n > seen) {
      const msg = '⛔ TrustMe chặn ' + (n - seen) + ' hành động:\n' + (j.last || []).slice(-(n - seen)).join('\n');
      execFile('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(process.argv[1], '..', 'notify.ps1')], { env: { ...process.env, TM_MSG: msg }, windowsHide: true }, () => {});
    }
    seen = n;
  } catch {}
}, 5000);
'@
Set-Content $f ($js + $add) -Encoding UTF8
}
node --check $f
Get-CimInstance Win32_Process -Filter "name='node.exe'" | Where-Object CommandLine -like '*server.mjs*' | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Process node -ArgumentList "`"$f`"" -WindowStyle Hidden
Start-Sleep 2
$env:TM_MSG = '✅ TrustMe đã nối Telegram: có hành động bị chặn em sẽ báo anh.'
powershell -NoProfile -File (Join-Path $d 'notify.ps1')
Write-Host 'Xong. Kiểm tra Telegram.'
