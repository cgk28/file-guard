#!/usr/bin/env node
// TrustMe adapter for Claude Code hooks. Runs the SAME rules as the AICoworker plugin (../../plugin/plugin.js).
// Events: PreToolUse (block), PostToolUse (mark untrusted content read), Stop (clear mark).
// Block = exit code 2 + reason on stderr (Claude Code shows it to the model).
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');

const PLUGIN = process.env.TRUSTME_PLUGIN || path.join(__dirname, '..', '..', 'plugin', 'plugin.js');
const STATE = process.env.TRUSTME_STATE || path.join(os.homedir(), '.trustme', 'state.json');
const PROTECTED = process.env.TRUSTME_PROTECTED ||
  'agents.md\nclaude.md\nsoul.md\ntools.md\nidentity.md\nsettings.json\n.claude/\nskills/file-guard\nfile-guard-baseline\n.file-guard';

// Claude Code tool names -> the names the rules know
const MAP = { Bash: 'exec', WebFetch: 'web_fetch', WebSearch: 'web_search', NotebookEdit: 'notebook_edit' };
function params(tool, i) {
  i = i || {};
  if (tool === 'Bash') return { command: i.command || '' };
  return i; // Write/Edit already use file_path
}

function loadState() { try { return JSON.parse(fs.readFileSync(STATE, 'utf8')); } catch { return {}; } }
function saveState(s) { try { fs.mkdirSync(path.dirname(STATE), { recursive: true }); fs.writeFileSync(STATE, JSON.stringify(s)); } catch {} }

// minimal host: same shape the plugin expects ($.store, $.log, $.ui, $.clock, on)
function makeHost() {
  const state = loadState();
  const handlers = [];
  const $ = {
    store: { get: async (k) => (k in state ? state[k] : null), set: async (k, v) => { state[k] = v; }, delete: async (k) => { delete state[k]; } },
    log: { warn() {}, info() {}, error() {} },
    ui: { invalidate: async () => {} },
    clock: { now: () => Date.now() },
  };
  const on = (ev, a, b) => handlers.push({ ev, match: typeof a === 'function' ? null : a, fn: typeof a === 'function' ? a : b });
  return { $, on, handlers, state };
}

async function run(host, ev, e) {
  const list = host.handlers.filter((h) => h.ev === ev && (!h.match || Object.entries(h.match).every(([k, v]) => (Array.isArray(v) ? v.includes(e[k]) : e[k] === v))));
  let i = 0;
  const next = async (x) => (i < list.length ? list[i++].fn(host.$, x, next) : x);
  return next(e);
}

(async () => {
  let input = '';
  for await (const c of process.stdin) input += c;
  let msg; try { msg = JSON.parse(input); } catch { process.exit(0); }
  globalThis.h = () => null;
  const host = makeHost();
  require(PLUGIN).register(host.on, { protected: PROTECTED, taint: true });
  const tool = MAP[msg.tool_name] || msg.tool_name;
  const sessionKey = msg.session_id || 'cc';
  const ev = msg.hook_event_name;
  let code = 0;
  if (ev === 'PreToolUse') {
    const r = await run(host, 'tool.call', { tool, params: params(msg.tool_name, msg.tool_input), sessionKey, cwd: msg.cwd });
    if (r && r.deny) { process.stderr.write(r.deny + '\n'); code = 2; }
  } else if (ev === 'PostToolUse') {
    await run(host, 'tool.result', { tool, params: params(msg.tool_name, msg.tool_input), sessionKey });
  } else if (ev === 'Stop') {
    await run(host, 'turn.end', { sessionKey });
  }
  saveState(host.state);
  process.exit(code);
})();
